"""
example_run_all.py
Runs every classifier in the repo (both Scratch and Sklearn versions)
on the same synthetic dataset and prints a comparison table.
Run: python3 examples/example_run_all.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "code"))

import numpy as np
from utils import train_test_split, StandardScaler, accuracy_score

from logistic_regression import LogisticRegressionScratch, LogisticRegressionSklearn
from naive_bayes import GaussianNBScratch, NaiveBayesSklearn
from knn import KNNClassifierScratch, KNNSklearn
from decision_tree import DecisionTreeScratch, DecisionTreeSklearn
from random_forest import RandomForestScratch, RandomForestSklearn
from boosting import GradientBoostingScratch, BoostingSklearn
from svm import LinearSVMScratch, SVMSklearn


def make_dataset(n=300, seed=0):
    rng = np.random.RandomState(seed)
    X = np.vstack([rng.randn(n // 2, 2) + [2, 2], rng.randn(n // 2, 2) + [-2, -2]])
    y = np.array([1] * (n // 2) + [0] * (n // 2))
    return X, y


if __name__ == "__main__":
    X, y = make_dataset()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)
    scaler = StandardScaler().fit(X_train)
    X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

    models = [
        ("Logistic Regression", LogisticRegressionScratch(learning_rate=0.5, n_iterations=500), LogisticRegressionSklearn()),
        ("Naive Bayes", GaussianNBScratch(), NaiveBayesSklearn(variant="gaussian")),
        ("KNN", KNNClassifierScratch(k=5, weighted=True), KNNSklearn(k=5)),
        ("Decision Tree", DecisionTreeScratch(max_depth=4), DecisionTreeSklearn(max_depth=4)),
        ("Random Forest", RandomForestScratch(n_trees=20, max_depth=4), RandomForestSklearn(n_trees=100)),
        ("Gradient Boosting", GradientBoostingScratch(n_estimators=30, learning_rate=0.3, max_depth=2), BoostingSklearn()),
        ("SVM", LinearSVMScratch(C=1.0, learning_rate=0.001, n_iterations=1000), SVMSklearn(kernel="rbf")),
    ]

    print(f"{'Model':<22}{'Scratch Acc':<15}{'Sklearn Acc':<15}")
    print("-" * 52)
    for name, scratch_model, sklearn_model in models:
        scratch_model.fit(X_train_s, y_train)
        sklearn_model.fit(X_train_s, y_train)
        acc_scratch = accuracy_score(y_test, scratch_model.predict(X_test_s))
        acc_sklearn = accuracy_score(y_test, sklearn_model.predict(X_test_s))
        print(f"{name:<22}{acc_scratch:<15.3f}{acc_sklearn:<15.3f}")
