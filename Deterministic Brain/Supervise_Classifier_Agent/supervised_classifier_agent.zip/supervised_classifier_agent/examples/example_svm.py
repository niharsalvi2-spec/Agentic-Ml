"""
example_svm.py
Runnable end-to-end demo: synthetic data -> train -> evaluate,
for both the from-scratch and scikit-learn implementations.
Run: python3 examples/example_svm.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "code"))

import numpy as np
from svm import LinearSVMScratch, SVMSklearn
from utils import train_test_split, StandardScaler, accuracy_score, precision_recall_f1

def make_dataset(n=300, seed=0):
    rng = np.random.RandomState(seed)
    X = np.vstack([rng.randn(n // 2, 2) + [2, 2], rng.randn(n // 2, 2) + [-2, -2]])
    y = np.array([1] * (n // 2) + [0] * (n // 2))
    return X, y

if __name__ == "__main__":
    X, y = make_dataset()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

    scaler = StandardScaler().fit(X_train)
    X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

    scratch = LinearSVMScratch(C=1.0, learning_rate=0.001, n_iterations=1000).fit(X_train_s, y_train)
    pred_scratch = scratch.predict(X_test_s)
    p, r, f1 = precision_recall_f1(y_test, pred_scratch)
    print(f"[Scratch]  acc={accuracy_score(y_test, pred_scratch):.3f}  precision={p:.3f}  recall={r:.3f}  f1={f1:.3f}")

    sk = SVMSklearn(kernel="rbf").fit(X_train_s, y_train)
    pred_sk = sk.predict(X_test_s)
    p, r, f1 = precision_recall_f1(y_test, pred_sk)
    print(f"[Sklearn]  acc={accuracy_score(y_test, pred_sk):.3f}  precision={p:.3f}  recall={r:.3f}  f1={f1:.3f}")
