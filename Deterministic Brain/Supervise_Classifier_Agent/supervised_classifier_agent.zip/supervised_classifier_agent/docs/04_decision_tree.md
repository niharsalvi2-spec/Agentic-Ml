# Decision Tree Classifier

**Code:** `code/decision_tree.py` — `DecisionTreeScratch`, `DecisionTreeSklearn`

## Difference from regression trees
Regression tree leaf → predicts the mean. Classification tree leaf →
predicts the **majority class**. Splits are chosen by impurity
reduction instead of variance reduction.

## Gini Impurity
```
Gini = 1 - Σ p_k²
```
- Pure node (one class only): Gini = 0
- Maximally mixed (50/50 binary): Gini = 0.5
Interpretation: probability of misclassifying a randomly picked sample
if labeled according to the node's class distribution.

## Entropy (alternative criterion)
```
Entropy = -Σ p_k * log2(p_k)
```
Pure node → 0. Maximum uncertainty (50/50 binary) → 1.0.
`Information Gain = entropy_before - weighted_entropy_after_split`.

Gini vs Entropy: Gini is faster (no log), usually produces the same
tree shape in practice. sklearn defaults to Gini.

## How a split is chosen
Try every feature and every candidate threshold; pick the split with
the lowest **weighted impurity** across the two children.

## Leaf prediction
```
P(class) = count_of_class_in_leaf / total_samples_in_leaf
```

## Controlling complexity (pruning)
Pre-pruning (stop early): `max_depth`, `min_samples_split`,
`min_samples_leaf`, `min_impurity_decrease`.
Post-pruning: grow full tree, then minimize
`cost = classification_error + α * tree_size` via cross-validated α.

## When to use
✓ Need interpretability, nonlinear boundaries, mixed feature types,
no scaling required.
✗ Prone to overfitting alone (see Random Forest), unstable to small
data changes (high variance) — that instability is exactly what
Random Forest fixes by averaging many trees.
