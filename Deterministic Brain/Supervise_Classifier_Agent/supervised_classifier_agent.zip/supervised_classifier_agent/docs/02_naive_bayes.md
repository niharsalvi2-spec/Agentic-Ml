# Naive Bayes

**Code:** `code/naive_bayes.py` — `GaussianNBScratch`, `NaiveBayesSklearn`
(variants: gaussian / multinomial / bernoulli)

## Core idea — Bayes' theorem
```
P(class | features) ∝ P(features | class) * P(class)
        posterior          likelihood         prior
```
Pick the class with the highest posterior probability.

## The "naive" assumption
Assumes features are **independent given the class**:
```
P(w1, w2, w3 | spam) = P(w1|spam) * P(w2|spam) * P(w3|spam)
```
This is almost never literally true (e.g. "free" and "money" co-occur
in spam), but Naive Bayes only needs to **rank** classes correctly, not
produce accurate probabilities — so it still works well in practice.

## Three variants
| Variant | Feature type | Use case |
|---|---|---|
| Gaussian | Continuous | numeric features, assumes Normal distribution per class |
| Multinomial | Counts | word counts in documents (text classification) |
| Bernoulli | Binary presence/absence | short documents, "does word appear?" |

### Gaussian formula
```
P(x|class=c) = (1/√(2πσ²_c)) * exp(-(x-μ_c)² / (2σ²_c))
```

### Multinomial + Laplace smoothing
```
P(word|class) = (count(word,class) + α) / (total_words(class) + α*vocab_size)
```
α (usually 1) prevents zero probability for unseen words — without it,
a single never-before-seen word makes the whole class probability 0.

## Why it's fast
Training = just compute means/variances/counts. No gradient descent.
O(n×p) training, O(p×k) prediction — scales to millions of features.

## When to use
✓ Text classification, small datasets, real-time prediction, NLP baselines.
✗ Strongly correlated features, complex continuous distributions, need
well-calibrated probabilities (NB probabilities tend to be extreme).
