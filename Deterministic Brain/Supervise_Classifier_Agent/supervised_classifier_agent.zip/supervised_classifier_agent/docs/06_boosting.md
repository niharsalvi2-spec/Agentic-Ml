# Gradient Boosting / XGBoost / LightGBM / CatBoost

**Code:** `code/boosting.py` — `GradientBoostingScratch`, `BoostingSklearn`
(`backend='sklearn'|'xgboost'|'lightgbm'`)

## Core idea
Same sequential "each tree fixes the previous tree's mistakes" idea as
boosted regression, but the loss function changes:
- Regression → MSE, residual = actual - predicted
- Classification → **Log Loss** (cross-entropy), residual = actual_label - predicted_probability

## Gradient of log loss
```
gradient = predicted_probability - actual_label   (P - y)
```
y=1, P=0.2 → gradient = -0.8 (strong push to raise probability)
y=0, P=0.9 → gradient = +0.9 (strong push to lower probability)
Each new tree is fit to these gradients.

## Raw score → probability
Boosted models output a raw log-odds score; apply:
- **sigmoid** for binary classification
- **softmax** for multiclass

## Key hyperparameters by library
| Library | Binary objective | Multiclass objective | Imbalance handling |
|---|---|---|---|
| XGBoost | `binary:logistic` | `multi:softmax` / `multi:softprob` | `scale_pos_weight = neg/pos` |
| LightGBM | `binary` | `multiclass` (+ `num_class`) | `is_unbalance=True` |
| CatBoost | `Logloss` | `MultiClass` | `auto_class_weights='Balanced'` |

## When to use
✓ Best-in-class accuracy on tabular data, medium-to-large datasets.
Prefer LightGBM for very large data, CatBoost for many categorical
features, XGBoost as the reliable general default.
✗ Very small datasets (overfits easily), need full interpretability
(these are ensembles, only partially interpretable via feature
importance / SHAP).
