# K-Nearest Neighbors (KNN)

**Code:** `code/knn.py` — `KNNClassifierScratch`, `KNNSklearn`

## Core idea
"Show me your friends and I'll tell you who you are." No training phase
(lazy learner) — just store the data. At prediction time, find the K
closest training points and let them vote.

## Voting
Majority vote among K neighbors. Use **odd K** for binary classification
to avoid ties.

## Distance-weighted voting
Closer neighbors get more say:
```
weight = 1 / distance
```
A neighbor at distance 0.1 should count far more than one at distance 5.0.

## Effect of K
| K | Boundary | Bias/Variance |
|---|---|---|
| K=1 | jagged, memorizes training data | low bias, high variance (overfits) |
| K=3–5 | smooth, good balance | usually the sweet spot |
| K=large | very smooth, may miss local patterns | high bias, low variance (underfits) |
| K=n (all points) | always predicts majority class | maximum underfit |

## Probability estimates
```
P(class c) = (neighbors of class c) / K
```
Coarse — only K+1 possible values. Not well-calibrated; prefer Logistic
Regression when calibrated probabilities matter.

## Feature scaling is MANDATORY
Distance is dominated by whichever feature has the largest numeric range.
Example: age (20–70) vs income (20,000–200,000) — income silently
swamps the distance calculation and age becomes irrelevant. Always
`StandardScaler` (see `code/utils.py`) before fitting KNN.

## When to use
✓ No training time needed (real-time-only pipelines), simple nonlinear
boundaries, small-to-medium datasets.
✗ High-dimensional data (curse of dimensionality), need fast prediction
on large datasets, need calibrated probabilities.
