# Model Selection Guide

Quick decision tree for picking a classifier. Point your agent here
first before writing new model code — it may already exist in `code/`.

```
Need interpretable model?
├── Simple linear boundary       → Logistic Regression
└── Nonlinear, tree structure    → Decision Tree

Need best accuracy on tabular data?
├── Large dataset                → LightGBM
├── Many categorical features    → CatBoost
├── Medium dataset               → XGBoost or Random Forest
└── Small dataset                → SVM (RBF kernel)

Text classification?
├── Simple, fast baseline        → Multinomial Naive Bayes
├── Better accuracy              → Logistic Regression
└── Best accuracy                → XGBoost / LightGBM on TF-IDF features

Need probability estimates?
├── Well-calibrated              → Logistic Regression
├── Approximate                  → Random Forest / Gradient Boosting
└── Avoid for this               → SVM (uncalibrated), Naive Bayes (extreme probs)

Very small dataset (<200 samples)?
├── Naive Bayes
├── SVM (RBF kernel)
└── Logistic Regression + regularization

Class imbalance?
├── class_weight='balanced'      → Random Forest, LightGBM, XGBoost
├── scale_pos_weight             → XGBoost
└── SMOTE preprocessing          → any model

No training time allowed (real-time only)?
└── KNN (lazy learner, zero training phase)
```

## Model comparison table

| Model | Boundary | Nonlinear | Probability Output | Interpretable | Dataset Size |
|---|---|---|---|---|---|
| Logistic Regression | Linear | No | Yes (calibrated) | Yes | Any |
| Naive Bayes | Linear | No | Yes (uncalibrated) | Yes | Small–Large |
| KNN | Nonlinear | Yes | Approximate | No | Small–Medium |
| Decision Tree | Nonlinear | Yes | Yes | Yes | Any |
| Random Forest | Nonlinear | Yes | Yes | Partial | Medium–Large |
| Gradient Boosting / XGBoost / LightGBM / CatBoost | Nonlinear | Yes | Yes | Partial | Medium–Large |
| SVM (linear) | Linear | No | No (needs calibration) | Partial | Small–Medium |
| SVM (RBF) | Nonlinear | Yes | No (needs calibration) | No | Small–Medium |

## Repo map for agents
```
code/utils.py               shared helpers: split, scaler, metrics
code/logistic_regression.py LogisticRegressionScratch, LogisticRegressionSklearn
code/naive_bayes.py         GaussianNBScratch, NaiveBayesSklearn
code/knn.py                 KNNClassifierScratch, KNNSklearn
code/decision_tree.py       DecisionTreeScratch, DecisionTreeSklearn
code/random_forest.py       RandomForestScratch, RandomForestSklearn
code/boosting.py            GradientBoostingScratch, BoostingSklearn
code/svm.py                 LinearSVMScratch, SVMSklearn
docs/01-08_*.md              theory reference, one file per model + this guide
examples/example_*.py        runnable end-to-end usage per model
```
Every "Scratch" class and every "Sklearn"-wrapper class in this repo
share the same API: `fit(X, y)`, `predict(X)`, `predict_proba(X)`.
Swap one for another without changing calling code.
