# Support Vector Machine (SVM)

**Code:** `code/svm.py` — `LinearSVMScratch`, `SVMSklearn`

## Core idea — maximum margin
Logistic Regression draws *any* line that separates classes. SVM finds
the line with the **maximum distance** from both classes — "the widest
possible road between two groups." A wider margin generalizes better.

## Support vectors
The training points closest to the boundary — the only points that
define where the boundary sits. Remove a non-support-vector and the
boundary doesn't move. Typically only 10–30% of points are support
vectors, which is why SVM is memory-efficient.

## Margin math
```
Decision boundary: w.x + b = 0
Margin boundaries: w.x + b = +1  and  w.x + b = -1
Margin width = 2 / ||w||
```
Maximizing the margin = minimizing `||w||`, subject to every point
being correctly classified and outside the margin.

## Soft margin (C parameter)
Real data usually isn't perfectly separable, so slack variables ξ_i
allow violations:
```
Minimize: (1/2)||w||² + C * Σξ_i
```
- High C: punish violations heavily → narrow margin, fits training data closely (risk of overfit).
- Low C: tolerate violations → wide margin, more generalization (risk of underfit).

## Kernel trick (nonlinear boundaries)
Implicitly projects data into higher dimensions where it becomes
linearly separable, without ever computing the new coordinates directly.
| Kernel | Formula | Use when |
|---|---|---|
| Linear | `x.y` | already linearly separable |
| Polynomial | `(γx.y + r)^d` | polynomial relationship |
| RBF | `exp(-γ‖x-y‖²)` | unknown shape — default choice |
| Sigmoid | `tanh(γx.y + r)` | rarely used |

### Gamma (RBF)
High γ → each point only influences close neighbors → tight, wiggly
boundary (overfit risk). Low γ → each point influences the whole
dataset → smooth boundary (underfit risk). Cross-validate C and γ
together (GridSearchCV).

## Multiclass
- One-vs-Rest (OvR): k binary SVMs, one per class.
- One-vs-One (OvO): k(k-1)/2 binary SVMs, one per class pair, majority vote.

## SVM vs Logistic Regression
| | SVM | Logistic Regression |
|---|---|---|
| Objective | Maximize margin | Maximize likelihood |
| Probabilities | Needs calibration | Native, calibrated |
| Kernels | Yes | Limited |
| Large datasets | Slow (O(n²)-O(n³)) | Fast |
| Interpretability | Low | High |

## When to use
✓ Small-to-medium datasets, high-dimensional data, need nonlinear
boundary via kernel, outliers are rare.
✗ Very large datasets (training is slow), need calibrated probabilities
out of the box, need model interpretability.
