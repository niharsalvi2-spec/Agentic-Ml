# Random Forest Classifier

**Code:** `code/random_forest.py` — `RandomForestScratch`, `RandomForestSklearn`

## Core idea
Bag many decision trees, each trained on a bootstrap sample with a
random subset of features, then take a **majority vote**.
```
73/100 trees vote spam → predict spam, P(spam) ≈ 0.73
```

## Why it beats a single tree
A single tree is highly sensitive to the training data (high variance).
Averaging many differently-noisy trees produces a smooth, stable
consensus boundary — "100 independent doctors voting" beats one doctor.

## Class imbalance handling
Problem: 950 healthy vs 50 diabetic → a naive tree predicts "healthy"
always and gets 95% accuracy while being useless.

Fixes:
- `class_weight='balanced'`: weight = n_samples / (n_classes * class_count).
  A minority class with 50/1000 samples gets weighted ~19x more heavily.
- `class_weight={0: 1, 1: 19}`: manual weighting.
- `max_samples` / undersampling: balance classes within each bootstrap.

## When to use
✓ Medium-to-large tabular data, need robustness over a single tree,
partial interpretability (feature importances) still wanted.
✗ Very high-dimensional sparse data (e.g. raw text) — gradient boosting
or linear models usually do better there.
