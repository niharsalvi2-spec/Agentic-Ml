# Logistic Regression

**Code:** `code/logistic_regression.py` — `LogisticRegressionScratch`, `LogisticRegressionSklearn`

## What it is
A classification algorithm despite the name. Takes a linear score
`z = w0 + w1*x1 + w2*x2 + ...` and squishes it into a 0–1 probability
with the sigmoid function.

## Sigmoid
```
sigmoid(z) = 1 / (1 + e^-z)
```
- z → -∞ : output → 0
- z = 0  : output = 0.5
- z → +∞ : output → 1

## Decision rule
```
P(class=1) > threshold  → predict 1
P(class=1) <= threshold → predict 0
```
Default threshold = 0.5, but tune it:
- Medical screening: lower threshold (e.g. 0.3) — catch more true positives.
- Fraud blocking: higher threshold (e.g. 0.8) — avoid blocking real customers.

## Decision boundary
Always a straight line / plane / hyperplane: `w0 + w1x1 + w2x2 = 0`.
Cannot separate curved class boundaries — that's its core limitation.

## Loss function: Binary Cross-Entropy
```
Loss = -[y*log(P) + (1-y)*log(1-P)]
```
Confidently wrong predictions are punished severely (loss → ∞);
confidently correct predictions are rewarded (loss → 0). MSE is not
used because it makes the loss surface non-convex here.

## Training
No closed-form solution — trained with gradient descent:
```
gradient = (1/n) * Σ (predicted - actual) * feature
w_new = w_old - learning_rate * gradient
```

## Multiclass
Use **softmax** instead of sigmoid:
```
P(class k) = e^(z_k) / Σ_j e^(z_j)
```
Outputs sum to exactly 1.0.

## Regularization
- L2 (Ridge): `Loss + λΣw²` — shrinks weights, stabilizes.
- L1 (Lasso): `Loss + λΣ|w|` — zeroes out irrelevant features.
- sklearn's `C = 1/λ`: small C = strong regularization, large C = weak.

## When to use
✓ Linear boundary is enough, need probabilities, need interpretability, large datasets, good baseline.
✗ Classes not linearly separable, complex feature interactions.
