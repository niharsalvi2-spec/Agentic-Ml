"""
random_forest.py
=================
Ensemble of decision trees, each trained on a bootstrap sample with a
random subset of features; final prediction is a majority vote.
See docs/05_random_forest.md.

Two implementations:
    RandomForestScratch  - pure NumPy, bags DecisionTreeScratch trees
    RandomForestSklearn   - wraps sklearn.ensemble.RandomForestClassifier
"""
import numpy as np

try:
    from decision_tree import DecisionTreeScratch
except ImportError:
    from code.decision_tree import DecisionTreeScratch

try:
    from sklearn.ensemble import RandomForestClassifier as _SkRF
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


class RandomForestScratch:
    """Bootstrap-aggregated (bagged) ensemble of DecisionTreeScratch trees."""

    def __init__(self, n_trees=20, max_depth=5, max_features="sqrt",
                 random_state=42, class_weight=None):
        self.n_trees = n_trees
        self.max_depth = max_depth
        self.max_features = max_features
        self.random_state = random_state
        self.class_weight = class_weight  # e.g. {0: 1, 1: 19} for imbalance
        self.trees = []
        self.feature_subsets = []
        self.classes_ = None

    def _n_features_to_use(self, n_features):
        if self.max_features == "sqrt":
            return max(1, int(np.sqrt(n_features)))
        if self.max_features == "log2":
            return max(1, int(np.log2(n_features)))
        if isinstance(self.max_features, int):
            return min(self.max_features, n_features)
        return n_features

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        n_samples, n_features = X.shape
        rng = np.random.RandomState(self.random_state)

        # sample weights for class_weight='balanced'-style handling
        if self.class_weight == "balanced":
            counts = {c: np.sum(y == c) for c in self.classes_}
            weight_map = {c: n_samples / (len(self.classes_) * counts[c]) for c in self.classes_}
        elif isinstance(self.class_weight, dict):
            weight_map = self.class_weight
        else:
            weight_map = {c: 1.0 for c in self.classes_}

        self.trees, self.feature_subsets = [], []
        k = self._n_features_to_use(n_features)

        for i in range(self.n_trees):
            tree_rng = np.random.RandomState(self.random_state + i)
            # bootstrap sample, oversampling rows by class weight
            sample_weights = np.array([weight_map[label] for label in y])
            sample_weights /= sample_weights.sum()
            boot_idx = tree_rng.choice(n_samples, size=n_samples, replace=True, p=sample_weights)
            feat_idx = tree_rng.choice(n_features, size=k, replace=False)

            tree = DecisionTreeScratch(max_depth=self.max_depth)
            tree.fit(X[boot_idx][:, feat_idx], y[boot_idx])

            self.trees.append(tree)
            self.feature_subsets.append(feat_idx)
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        class_idx = {c: i for i, c in enumerate(self.classes_)}
        votes = np.zeros((len(X), len(self.classes_)))

        for tree, feat_idx in zip(self.trees, self.feature_subsets):
            preds = tree.predict(X[:, feat_idx])
            for row, p in enumerate(preds):
                votes[row, class_idx[p]] += 1

        return votes / votes.sum(axis=1, keepdims=True)

    def predict(self, X):
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]


class RandomForestSklearn:
    """Thin wrapper around sklearn's RandomForestClassifier."""

    def __init__(self, n_trees=100, max_depth=None, class_weight=None, random_state=42):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        self.model = _SkRF(n_estimators=n_trees, max_depth=max_depth,
                            class_weight=class_weight, random_state=random_state)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = RandomForestScratch(n_trees=15, max_depth=4).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = RandomForestSklearn(n_trees=100).fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
