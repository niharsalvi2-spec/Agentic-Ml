"""
naive_bayes.py
==============
Bayes' theorem + the "naive" assumption that features are independent
given the class. See docs/02_naive_bayes.md.

Two implementations:
    GaussianNBScratch  - pure NumPy Gaussian Naive Bayes (continuous features)
    NaiveBayesSklearn   - wraps sklearn Gaussian / Multinomial / Bernoulli NB
"""
import numpy as np

try:
    from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


class GaussianNBScratch:
    """Gaussian Naive Bayes: assumes each feature is Normal within a class."""

    def __init__(self, var_smoothing=1e-9):
        self.var_smoothing = var_smoothing
        self.classes_ = None
        self.mean_ = {}
        self.var_ = {}
        self.priors_ = {}

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        n_samples = len(y)

        for c in self.classes_:
            X_c = X[y == c]
            self.mean_[c] = X_c.mean(axis=0)
            self.var_[c] = X_c.var(axis=0) + self.var_smoothing
            self.priors_[c] = len(X_c) / n_samples
        return self

    def _log_gaussian(self, X, mean, var):
        # log of the Gaussian PDF, summed across features (== product of
        # per-feature likelihoods, the "naive" independence assumption)
        return -0.5 * np.sum(np.log(2 * np.pi * var)) - 0.5 * np.sum(
            ((X - mean) ** 2) / var, axis=1
        )

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        log_probs = []
        for c in self.classes_:
            log_prior = np.log(self.priors_[c])
            log_likelihood = self._log_gaussian(X, self.mean_[c], self.var_[c])
            log_probs.append(log_prior + log_likelihood)
        log_probs = np.array(log_probs).T  # (n_samples, n_classes)

        # softmax for numerical stability -> normalized probabilities
        log_probs -= log_probs.max(axis=1, keepdims=True)
        probs = np.exp(log_probs)
        probs /= probs.sum(axis=1, keepdims=True)
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]


class NaiveBayesSklearn:
    """Wraps sklearn's Gaussian / Multinomial / Bernoulli Naive Bayes."""

    def __init__(self, variant="gaussian", alpha=1.0):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        variant = variant.lower()
        if variant == "gaussian":
            self.model = GaussianNB()
        elif variant == "multinomial":
            self.model = MultinomialNB(alpha=alpha)  # alpha = Laplace smoothing
        elif variant == "bernoulli":
            self.model = BernoulliNB(alpha=alpha)
        else:
            raise ValueError("variant must be 'gaussian', 'multinomial', or 'bernoulli'")

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = GaussianNBScratch().fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = NaiveBayesSklearn(variant="gaussian").fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
