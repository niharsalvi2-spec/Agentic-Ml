"""
knn.py
======
"You are defined by your neighbors." Lazy learner: no training phase,
just store the data and vote at prediction time. See docs/03_knn.md.

IMPORTANT: always StandardScaler your features before using KNN
(see utils.StandardScaler) or high-range features will dominate distance.

Two implementations:
    KNNClassifierScratch  - pure NumPy, brute-force distance + weighted voting
    KNNSklearn             - wraps sklearn.neighbors.KNeighborsClassifier
"""
import numpy as np
from collections import Counter

try:
    from sklearn.neighbors import KNeighborsClassifier as _SkKNN
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


class KNNClassifierScratch:
    """K-Nearest-Neighbors with optional distance-weighted voting."""

    def __init__(self, k=5, weighted=False):
        self.k = k
        self.weighted = weighted
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        self.X_train = np.asarray(X, dtype=float)
        self.y_train = np.asarray(y)
        return self

    def _distances(self, x):
        return np.sqrt(np.sum((self.X_train - x) ** 2, axis=1))

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        classes = np.unique(self.y_train)
        class_idx = {c: i for i, c in enumerate(classes)}
        probs = np.zeros((len(X), len(classes)))

        for row, x in enumerate(X):
            dist = self._distances(x)
            nn_idx = np.argsort(dist)[: self.k]
            nn_labels = self.y_train[nn_idx]
            nn_dist = dist[nn_idx]

            if self.weighted:
                weights = 1.0 / (nn_dist + 1e-9)
            else:
                weights = np.ones_like(nn_dist)

            for lbl, w in zip(nn_labels, weights):
                probs[row, class_idx[lbl]] += w

            probs[row] /= probs[row].sum()

        self.classes_ = classes
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]


class KNNSklearn:
    """Thin wrapper around sklearn's KNeighborsClassifier."""

    def __init__(self, k=5, weights="uniform"):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        # weights: "uniform" (majority vote) or "distance" (1/distance weighting)
        self.model = _SkKNN(n_neighbors=k, weights=weights)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = KNNClassifierScratch(k=5, weighted=True).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = KNNSklearn(k=5).fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
