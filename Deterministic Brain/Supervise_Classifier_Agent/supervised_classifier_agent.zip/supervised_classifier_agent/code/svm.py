"""
svm.py
======
Finds the maximum-margin boundary between classes (the "widest road"),
defined only by the closest points (support vectors). See docs/07_svm.md.

Two implementations:
    LinearSVMScratch  - pure NumPy, hinge loss + gradient descent (soft margin)
    SVMSklearn          - wraps sklearn.svm.SVC (supports linear/poly/rbf/sigmoid kernels)
"""
import numpy as np

try:
    from sklearn.svm import SVC as _SkSVC
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


class LinearSVMScratch:
    """
    Soft-margin linear SVM trained with subgradient descent on the hinge loss:
        L = (1/2)||w||^2 + C * sum(max(0, 1 - y_i*(w.x_i + b)))
    Labels must be -1 / +1 (fit() converts 0/1 automatically).
    """

    def __init__(self, C=1.0, learning_rate=0.001, n_iterations=1000):
        self.C = C
        self.learning_rate = learning_rate
        self.n_iterations = n_iterations
        self.w = None
        self.b = 0.0

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        y = np.where(y <= 0, -1.0, 1.0)  # convert 0/1 -> -1/+1

        n_samples, n_features = X.shape
        self.w = np.zeros(n_features)
        self.b = 0.0

        for _ in range(self.n_iterations):
            scores = X @ self.w + self.b
            margin = y * scores
            violates = margin < 1  # points inside the margin or misclassified

            # gradient of hinge loss: regularization term always active,
            # data term only for margin violators
            dw = self.w - self.C * (X[violates].T @ y[violates] if violates.any() else 0.0)
            db = -self.C * np.sum(y[violates]) if violates.any() else 0.0

            self.w -= self.learning_rate * dw
            self.b -= self.learning_rate * db
        return self

    def decision_function(self, X):
        X = np.asarray(X, dtype=float)
        return X @ self.w + self.b

    def predict(self, X):
        return (self.decision_function(X) >= 0).astype(int)

    def support_vector_mask(self, X, y, tol=1e-2):
        """Points within tol of the margin boundary (|score| <= 1+tol)."""
        y = np.where(np.asarray(y) <= 0, -1.0, 1.0)
        margin = y * self.decision_function(X)
        return margin <= 1 + tol


class SVMSklearn:
    """
    Thin wrapper around sklearn's SVC.
    kernel: 'linear' | 'poly' | 'rbf' | 'sigmoid'
    gamma controls RBF "reach" (see docs/07_svm.md); probability=True
    enables predict_proba via internal cross-validated calibration.
    """

    def __init__(self, C=1.0, kernel="rbf", gamma="scale", degree=3, probability=True):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        self.model = _SkSVC(C=C, kernel=kernel, gamma=gamma, degree=degree,
                             probability=probability)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)

    @property
    def support_vectors_(self):
        return self.model.support_vectors_


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = LinearSVMScratch(C=1.0, learning_rate=0.001, n_iterations=1000).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = SVMSklearn(kernel="rbf").fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
