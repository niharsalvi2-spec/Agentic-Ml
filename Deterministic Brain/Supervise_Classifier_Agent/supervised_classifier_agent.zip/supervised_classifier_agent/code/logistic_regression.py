"""
logistic_regression.py
=======================
Binary classifier that squishes a linear score through the sigmoid
function to output a probability. See docs/01_logistic_regression.md.

Two implementations, identical fit/predict/predict_proba API:
    LogisticRegressionScratch  - pure NumPy, batch gradient descent, L2 option
    LogisticRegressionSklearn  - wraps sklearn.linear_model.LogisticRegression
"""
import numpy as np

try:
    from sklearn.linear_model import LogisticRegression as _SkLogReg
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))


class LogisticRegressionScratch:
    """Binary logistic regression trained with gradient descent + BCE loss."""

    def __init__(self, learning_rate=0.1, n_iterations=2000, l2=0.0, threshold=0.5):
        self.learning_rate = learning_rate
        self.n_iterations = n_iterations
        self.l2 = l2
        self.threshold = threshold
        self.weights = None
        self.bias = 0.0
        self.loss_history = []

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0.0
        self.loss_history = []

        for _ in range(self.n_iterations):
            z = X @ self.weights + self.bias
            p = _sigmoid(z)

            error = p - y  # gradient of cross-entropy w.r.t. z
            grad_w = (X.T @ error) / n_samples + (self.l2 / n_samples) * self.weights
            grad_b = np.mean(error)

            self.weights -= self.learning_rate * grad_w
            self.bias -= self.learning_rate * grad_b

            eps = 1e-15
            p_clip = np.clip(p, eps, 1 - eps)
            loss = -np.mean(y * np.log(p_clip) + (1 - y) * np.log(1 - p_clip))
            self.loss_history.append(loss)
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        p1 = _sigmoid(X @ self.weights + self.bias)
        return np.column_stack([1 - p1, p1])

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= self.threshold).astype(int)


class LogisticRegressionSklearn:
    """Thin wrapper around sklearn's LogisticRegression, same API as above."""

    def __init__(self, C=1.0, max_iter=1000):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        # sklearn auto-detects binary vs multiclass (softmax) internally
        self.model = _SkLogReg(C=C, max_iter=max_iter)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = LogisticRegressionScratch(learning_rate=0.5, n_iterations=500).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = LogisticRegressionSklearn().fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
