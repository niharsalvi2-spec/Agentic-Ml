"""
decision_tree.py
================
Recursively splits data using Gini impurity (or entropy) to separate
classes, leaf predicts the majority class. See docs/04_decision_tree.md.

Two implementations:
    DecisionTreeScratch  - pure NumPy, recursive binary splitting
    DecisionTreeSklearn   - wraps sklearn.tree.DecisionTreeClassifier
"""
import numpy as np

try:
    from sklearn.tree import DecisionTreeClassifier as _SkTree
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


def gini_impurity(y):
    if len(y) == 0:
        return 0.0
    _, counts = np.unique(y, return_counts=True)
    p = counts / counts.sum()
    return 1.0 - np.sum(p ** 2)


def entropy_impurity(y):
    if len(y) == 0:
        return 0.0
    _, counts = np.unique(y, return_counts=True)
    p = counts / counts.sum()
    p = p[p > 0]
    return -np.sum(p * np.log2(p))


class _Node:
    __slots__ = ("feature", "threshold", "left", "right", "value", "proba")

    def __init__(self, feature=None, threshold=None, left=None, right=None,
                 value=None, proba=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value      # majority class, set only on leaves
        self.proba = proba      # class distribution, set only on leaves


class DecisionTreeScratch:
    """Binary decision tree classifier grown by greedy impurity reduction."""

    def __init__(self, max_depth=5, min_samples_split=2, criterion="gini"):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.criterion_fn = gini_impurity if criterion == "gini" else entropy_impurity
        self.root = None
        self.classes_ = None

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        self.root = self._grow(X, y, depth=0)
        return self

    def _leaf(self, y):
        counts = np.array([np.sum(y == c) for c in self.classes_])
        proba = counts / counts.sum()
        value = self.classes_[np.argmax(counts)]
        return _Node(value=value, proba=proba)

    def _best_split(self, X, y):
        n_samples, n_features = X.shape
        best_gain, best_feat, best_thr = -1.0, None, None
        parent_impurity = self.criterion_fn(y)

        for feat in range(n_features):
            thresholds = np.unique(X[:, feat])
            # try midpoints between consecutive unique values
            for thr in (thresholds[:-1] + thresholds[1:]) / 2 if len(thresholds) > 1 else []:
                left_mask = X[:, feat] <= thr
                right_mask = ~left_mask
                if left_mask.sum() == 0 or right_mask.sum() == 0:
                    continue

                left_imp = self.criterion_fn(y[left_mask])
                right_imp = self.criterion_fn(y[right_mask])
                weighted = (left_mask.sum() * left_imp + right_mask.sum() * right_imp) / n_samples
                gain = parent_impurity - weighted

                if gain > best_gain:
                    best_gain, best_feat, best_thr = gain, feat, thr

        return best_feat, best_thr, best_gain

    def _grow(self, X, y, depth):
        if (depth >= self.max_depth or len(y) < self.min_samples_split
                or len(np.unique(y)) == 1):
            return self._leaf(y)

        feat, thr, gain = self._best_split(X, y)
        if feat is None or gain <= 0:
            return self._leaf(y)

        left_mask = X[:, feat] <= thr
        left = self._grow(X[left_mask], y[left_mask], depth + 1)
        right = self._grow(X[~left_mask], y[~left_mask], depth + 1)
        return _Node(feature=feat, threshold=thr, left=left, right=right)

    def _predict_one(self, x, node):
        if node.value is not None:
            return node.value, node.proba
        if x[node.feature] <= node.threshold:
            return self._predict_one(x, node.left)
        return self._predict_one(x, node.right)

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        return np.array([self._predict_one(x, self.root)[0] for x in X])

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        return np.array([self._predict_one(x, self.root)[1] for x in X])


class DecisionTreeSklearn:
    """Thin wrapper around sklearn's DecisionTreeClassifier."""

    def __init__(self, max_depth=5, min_samples_split=2, criterion="gini"):
        if not _SKLEARN_AVAILABLE:
            raise ImportError("scikit-learn is not installed.")
        self.model = _SkTree(max_depth=max_depth, min_samples_split=min_samples_split,
                              criterion=criterion)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = DecisionTreeScratch(max_depth=4).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = DecisionTreeSklearn(max_depth=4).fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
