"""
boosting.py
===========
Gradient Boosting for classification: sequentially fit small regression
trees to the *gradient* of the log-loss (predicted_probability - actual),
then combine via sigmoid. Covers Gradient Boosting / XGBoost / LightGBM /
CatBoost conceptually. See docs/06_boosting.md.

Two implementations:
    GradientBoostingScratch  - pure NumPy, regression-stump boosting + sigmoid
    BoostingSklearn            - wraps sklearn.ensemble.GradientBoostingClassifier
                                  (falls back gracefully if xgboost/lightgbm
                                  are not installed; they are optional extras)
"""
import numpy as np

try:
    from sklearn.ensemble import GradientBoostingClassifier as _SkGB
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))


class _RegressionStump:
    """A single-split regression tree used as a weak learner (max_depth<=3)."""

    def __init__(self, max_depth=3, min_samples_split=5):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.tree = None

    def fit(self, X, residuals, depth=0):
        self.tree = self._grow(X, residuals, depth=0)
        return self

    def _grow(self, X, r, depth):
        n_samples, n_features = X.shape
        if depth >= self.max_depth or n_samples < self.min_samples_split:
            return {"leaf": True, "value": r.mean() if n_samples else 0.0}

        best_sse, best_feat, best_thr = np.inf, None, None
        for feat in range(n_features):
            thresholds = np.unique(X[:, feat])
            if len(thresholds) < 2:
                continue
            for thr in (thresholds[:-1] + thresholds[1:]) / 2:
                left = X[:, feat] <= thr
                right = ~left
                if left.sum() == 0 or right.sum() == 0:
                    continue
                sse = np.sum((r[left] - r[left].mean()) ** 2) + \
                      np.sum((r[right] - r[right].mean()) ** 2)
                if sse < best_sse:
                    best_sse, best_feat, best_thr = sse, feat, thr

        if best_feat is None:
            return {"leaf": True, "value": r.mean()}

        left_mask = X[:, best_feat] <= best_thr
        return {
            "leaf": False, "feature": best_feat, "threshold": best_thr,
            "left": self._grow(X[left_mask], r[left_mask], depth + 1),
            "right": self._grow(X[~left_mask], r[~left_mask], depth + 1),
        }

    def _predict_one(self, x, node):
        if node["leaf"]:
            return node["value"]
        branch = node["left"] if x[node["feature"]] <= node["threshold"] else node["right"]
        return self._predict_one(x, branch)

    def predict(self, X):
        return np.array([self._predict_one(x, self.tree) for x in X])


class GradientBoostingScratch:
    """Binary gradient boosting: additive regression stumps + log loss."""

    def __init__(self, n_estimators=50, learning_rate=0.1, max_depth=3):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.trees = []
        self.init_log_odds = 0.0

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        p = np.clip(y.mean(), 1e-6, 1 - 1e-6)
        self.init_log_odds = np.log(p / (1 - p))  # starting raw score

        raw_score = np.full(len(y), self.init_log_odds)
        self.trees = []

        for _ in range(self.n_estimators):
            proba = _sigmoid(raw_score)
            gradient = proba - y  # d(log_loss)/d(raw_score) = P - y
            stump = _RegressionStump(max_depth=self.max_depth).fit(X, -gradient)
            update = stump.predict(X)
            raw_score += self.learning_rate * update
            self.trees.append(stump)
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        raw_score = np.full(len(X), self.init_log_odds)
        for stump in self.trees:
            raw_score += self.learning_rate * stump.predict(X)
        p1 = _sigmoid(raw_score)
        return np.column_stack([1 - p1, p1])

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)


class BoostingSklearn:
    """
    Wraps sklearn's GradientBoostingClassifier by default.
    Pass backend='xgboost' or backend='lightgbm' to use those libraries
    if they are installed in your environment (optional extras, not
    included by default in this repo).
    """

    def __init__(self, backend="sklearn", n_estimators=100, learning_rate=0.1,
                 max_depth=3, scale_pos_weight=None):
        self.backend = backend
        if backend == "sklearn":
            if not _SKLEARN_AVAILABLE:
                raise ImportError("scikit-learn is not installed.")
            self.model = _SkGB(n_estimators=n_estimators, learning_rate=learning_rate,
                                max_depth=max_depth)
        elif backend == "xgboost":
            import xgboost as xgb  # optional dependency
            self.model = xgb.XGBClassifier(
                n_estimators=n_estimators, learning_rate=learning_rate,
                max_depth=max_depth, objective="binary:logistic",
                scale_pos_weight=scale_pos_weight or 1,
            )
        elif backend == "lightgbm":
            import lightgbm as lgb  # optional dependency
            self.model = lgb.LGBMClassifier(
                n_estimators=n_estimators, learning_rate=learning_rate,
                max_depth=max_depth, objective="binary",
            )
        else:
            raise ValueError("backend must be 'sklearn', 'xgboost', or 'lightgbm'")

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X = np.vstack([rng.randn(50, 2) + [2, 2], rng.randn(50, 2) + [-2, -2]])
    y = np.array([1] * 50 + [0] * 50)

    m = GradientBoostingScratch(n_estimators=30, learning_rate=0.3, max_depth=2).fit(X, y)
    print("Scratch accuracy:", np.mean(m.predict(X) == y))

    if _SKLEARN_AVAILABLE:
        m2 = BoostingSklearn(backend="sklearn").fit(X, y)
        print("Sklearn accuracy:", np.mean(m2.predict(X) == y))
